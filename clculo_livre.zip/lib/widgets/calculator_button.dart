import 'package:flutter/material.dart';
import 'package:clculo_livre/theme.dart';

class CalculatorButton extends StatefulWidget {
  final String text;
  final VoidCallback onPressed;
  final Color? backgroundColor;
  final Color? textColor;
  final double fontSize;

  const CalculatorButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.fontSize = 22,
  });

  @override
  State<CalculatorButton> createState() => _CalculatorButtonState();
}

class _CalculatorButtonState extends State<CalculatorButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    // Cores padrão baseadas no tema
    final defaultBackgroundColor = isDark 
      ? DarkModeColors.calculatorNumber.withValues(alpha: 0.15)
      : LightModeColors.calculatorNumber.withValues(alpha: 0.15);
    
    final defaultTextColor = isDark 
      ? DarkModeColors.calculatorNumber
      : LightModeColors.calculatorNumber;

    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: (widget.backgroundColor ?? defaultBackgroundColor)
                      .withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: widget.backgroundColor ?? defaultBackgroundColor,
              borderRadius: BorderRadius.circular(20),
              child: InkWell(
                onTap: () {
                  _animationController.forward().then((_) {
                    _animationController.reverse();
                  });
                  widget.onPressed();
                },
                borderRadius: BorderRadius.circular(20),
                splashColor: (widget.textColor ?? defaultTextColor)
                    .withValues(alpha: 0.2),
                highlightColor: (widget.textColor ?? defaultTextColor)
                    .withValues(alpha: 0.1),
                child: Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    widget.text,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontSize: widget.fontSize,
                      fontWeight: FontWeight.w600,
                      color: widget.textColor ?? defaultTextColor,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}