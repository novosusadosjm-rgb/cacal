import 'package:flutter/material.dart';
import 'package:clculo_livre/theme.dart';
import 'package:clculo_livre/widgets/calculator_button.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> with TickerProviderStateMixin {
  String _display = '0';
  String _previousValue = '';
  String _operation = '';
  bool _waitingForOperand = false;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onButtonPressed(String value) {
    _animationController.forward().then((_) {
      _animationController.reverse();
    });

    setState(() {
      if (value == 'C') {
        _clear();
      } else if (value == '⌫') {
        _backspace();
      } else if (['+', '-', '×', '÷'].contains(value)) {
        _setOperation(value);
      } else if (value == '=') {
        _calculate();
      } else if (value == '.') {
        _inputDecimal();
      } else {
        _inputNumber(value);
      }
    });
  }

  void _clear() {
    _display = '0';
    _previousValue = '';
    _operation = '';
    _waitingForOperand = false;
  }

  void _backspace() {
    if (_display.length > 1) {
      _display = _display.substring(0, _display.length - 1);
    } else {
      _display = '0';
    }
  }

  void _inputNumber(String number) {
    if (_waitingForOperand) {
      _display = number;
      _waitingForOperand = false;
    } else {
      _display = _display == '0' ? number : _display + number;
    }
  }

  void _inputDecimal() {
    if (_waitingForOperand) {
      _display = '0.';
      _waitingForOperand = false;
    } else if (!_display.contains('.')) {
      _display += '.';
    }
  }

  void _setOperation(String nextOperation) {
    if (_previousValue.isNotEmpty && !_waitingForOperand) {
      _calculate();
    }
    _previousValue = _display;
    _operation = nextOperation;
    _waitingForOperand = true;
  }

  void _calculate() {
    if (_previousValue.isEmpty || _operation.isEmpty) return;

    double prev = double.tryParse(_previousValue) ?? 0;
    double current = double.tryParse(_display) ?? 0;
    double result = 0;

    switch (_operation) {
      case '+':
        result = prev + current;
        break;
      case '-':
        result = prev - current;
        break;
      case '×':
        result = prev * current;
        break;
      case '÷':
        if (current != 0) {
          result = prev / current;
        } else {
          _display = 'Erro';
          _clear();
          return;
        }
        break;
    }

    String resultString = result.toString();
    if (result == result.toInt()) {
      resultString = result.toInt().toString();
    }

    _display = resultString;
    _previousValue = '';
    _operation = '';
    _waitingForOperand = true;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '🧮 Calculadora',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isDark 
                        ? DarkModeColors.calculatorAccent.withValues(alpha: 0.2)
                        : LightModeColors.calculatorAccent.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.calculate,
                      color: isDark 
                        ? DarkModeColors.calculatorAccent
                        : LightModeColors.calculatorAccent,
                      size: 28,
                    ),
                  ),
                ],
              ),
            ),
            
            // Display
            Expanded(
              flex: 2,
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 24),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: isDark 
                    ? const Color(0xFF2D2D2D)
                    : const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: isDark 
                      ? const Color(0xFF404040)
                      : const Color(0xFFE8EDF2),
                    width: 1,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (_previousValue.isNotEmpty && _operation.isNotEmpty)
                      Text(
                        '$_previousValue $_operation',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                        ),
                      ),
                    const SizedBox(height: 8),
                    AnimatedScale(
                      scale: _scaleAnimation.value,
                      duration: const Duration(milliseconds: 150),
                      child: Text(
                        _display,
                        style: Theme.of(context).textTheme.displayLarge?.copyWith(
                          fontWeight: FontWeight.w300,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Button Grid
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  children: [
                    // Primeira linha: C, ⌫, ÷
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: CalculatorButton(
                              text: 'C',
                              onPressed: () => _onButtonPressed('C'),
                              backgroundColor: isDark 
                                ? DarkModeColors.darkError.withValues(alpha: 0.2)
                                : LightModeColors.lightError.withValues(alpha: 0.2),
                              textColor: isDark 
                                ? DarkModeColors.darkError
                                : LightModeColors.lightError,
                              fontSize: 20,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CalculatorButton(
                              text: '⌫',
                              onPressed: () => _onButtonPressed('⌫'),
                              backgroundColor: isDark 
                                ? DarkModeColors.calculatorAccent.withValues(alpha: 0.2)
                                : LightModeColors.calculatorAccent.withValues(alpha: 0.2),
                              textColor: isDark 
                                ? DarkModeColors.calculatorAccent
                                : LightModeColors.calculatorAccent,
                              fontSize: 20,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CalculatorButton(
                              text: '÷',
                              onPressed: () => _onButtonPressed('÷'),
                              backgroundColor: isDark 
                                ? DarkModeColors.calculatorOperator.withValues(alpha: 0.2)
                                : LightModeColors.calculatorOperator.withValues(alpha: 0.2),
                              textColor: isDark 
                                ? DarkModeColors.calculatorOperator
                                : LightModeColors.calculatorOperator,
                              fontSize: 24,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Segunda linha: 7, 8, 9, ×
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(child: CalculatorButton(text: '7', onPressed: () => _onButtonPressed('7'))),
                          const SizedBox(width: 16),
                          Expanded(child: CalculatorButton(text: '8', onPressed: () => _onButtonPressed('8'))),
                          const SizedBox(width: 16),
                          Expanded(child: CalculatorButton(text: '9', onPressed: () => _onButtonPressed('9'))),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CalculatorButton(
                              text: '×',
                              onPressed: () => _onButtonPressed('×'),
                              backgroundColor: isDark 
                                ? DarkModeColors.calculatorOperator.withValues(alpha: 0.2)
                                : LightModeColors.calculatorOperator.withValues(alpha: 0.2),
                              textColor: isDark 
                                ? DarkModeColors.calculatorOperator
                                : LightModeColors.calculatorOperator,
                              fontSize: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Terceira linha: 4, 5, 6, -
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(child: CalculatorButton(text: '4', onPressed: () => _onButtonPressed('4'))),
                          const SizedBox(width: 16),
                          Expanded(child: CalculatorButton(text: '5', onPressed: () => _onButtonPressed('5'))),
                          const SizedBox(width: 16),
                          Expanded(child: CalculatorButton(text: '6', onPressed: () => _onButtonPressed('6'))),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CalculatorButton(
                              text: '-',
                              onPressed: () => _onButtonPressed('-'),
                              backgroundColor: isDark 
                                ? DarkModeColors.calculatorOperator.withValues(alpha: 0.2)
                                : LightModeColors.calculatorOperator.withValues(alpha: 0.2),
                              textColor: isDark 
                                ? DarkModeColors.calculatorOperator
                                : LightModeColors.calculatorOperator,
                              fontSize: 24,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Quarta linha: 1, 2, 3, +
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(child: CalculatorButton(text: '1', onPressed: () => _onButtonPressed('1'))),
                          const SizedBox(width: 16),
                          Expanded(child: CalculatorButton(text: '2', onPressed: () => _onButtonPressed('2'))),
                          const SizedBox(width: 16),
                          Expanded(child: CalculatorButton(text: '3', onPressed: () => _onButtonPressed('3'))),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CalculatorButton(
                              text: '+',
                              onPressed: () => _onButtonPressed('+'),
                              backgroundColor: isDark 
                                ? DarkModeColors.calculatorOperator.withValues(alpha: 0.2)
                                : LightModeColors.calculatorOperator.withValues(alpha: 0.2),
                              textColor: isDark 
                                ? DarkModeColors.calculatorOperator
                                : LightModeColors.calculatorOperator,
                              fontSize: 24,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Quinta linha: 0, ., =
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: CalculatorButton(text: '0', onPressed: () => _onButtonPressed('0')),
                          ),
                          const SizedBox(width: 16),
                          Expanded(child: CalculatorButton(text: '.', onPressed: () => _onButtonPressed('.'))),
                          const SizedBox(width: 16),
                          Expanded(
                            child: CalculatorButton(
                              text: '=',
                              onPressed: () => _onButtonPressed('='),
                              backgroundColor: isDark 
                                ? DarkModeColors.calculatorAccent
                                : LightModeColors.calculatorAccent,
                              textColor: Colors.white,
                              fontSize: 24,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}